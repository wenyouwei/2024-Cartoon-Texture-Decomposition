function [uk,vk,fk, out, Relerr_u, Relerr_v, Relerr_f] = LR_Weight_new(b, K, opts, OPTK)  % Algortthm ������� --- Ԥ��У��
%%%%% Input:
%%%%%       b   --- observed image
%%%%%       K    --- blur kernel
%%%%%       r    --- size of blocks
%%%%% output:
%%%%%       u    --- cartoon
%%%%%       v    --- texture

alpha = 0.38;

%% ������ʼ��
beta   = opts.beta;
lambda = opts.lambda;
mu    = opts.mu;
I     = opts.I;
%thr = opts.thr;

if isfield(opts, 'ur');       ur   =  opts.ur;        end
if isfield(opts, 'vr');       vr   =  opts.vr;        end
if isfield(opts, 'tau');      tau   =  opts.tau;        end
if isfield(opts, 'inneriter');    inneriter  =  opts.inneriter;        end
if isfield(opts, 'outeriter');    outeriter  =  opts.outeriter;        end

[n1,n2,n3] = size(b);
switch OPTK
    case 'I'  %%%%%%%%%%%%%%%%%%%%%%%%% K = I %%%%%%%%%%%%%%%%
        MDf   = 1 + beta;  KTb = b;
    case 'S'  %%%%%%%%%%%%%%%%%%%%%%%%% K = S %%%%%%%%%%%%%%%%
        MDf   = K + beta;  KTb = K.*b;
    case 'H'  %%%%%%%%%%%%%%%%%%%%%%%%% K = H %%%%%%%%%%%%%%%%
        siz = size(K); center = [fix(siz(1)/2+1),fix(siz(2)/2+1)];
        P   = zeros(n1,n2,n3); for i =1:n3; P(1:siz(1),1:siz(2),i) = K; end
        D   = fft2(circshift(P,1-center));
        H   = @(x) real(ifft2(D.*fft2(x)));       %%%% Blur operator.  B
        HT  = @(x) real(ifft2(conj(D).*fft2(x))); %%%% Transpose of blur operator.
        MDf = abs(D).^2 + beta;  KTb   = HT(b);
end



[L,D,~,~] = generateL(n1) ;
sz  = size(L,1)/2 ;
Wk = speye(2*sz);

fk = b;    yk =zeros(size(b));
yold = zeros(size(yk));
vk = zeros(size(fk)); 
uold = zeros(size(fk)); vold = vk; fold = fk;
tt = ones(1,outeriter);
i = 0; 
for k = 1:outeriter
    Weight(:,k) = diag(Wk);
    B=Wk*L;  B2 = B'*B;
    fprintf('Outer Iter : %d\n', k)
    for j=1:inneriter
        i = i+1;

        ub = fk + yk/beta - vk;
        Ab = beta*speye(size(B2))+lambda*B2;
        % uu = Ab\(beta*sparse(ub(:)));
        [uu, ~] = lsqr(Ab, beta * ub(:), 1e-6, 40);
        uk = full(reshape(uu,size(fk)));


      
        t =  fk+ yk./beta - uk;
        vk = SVT(t,mu/beta);

        Temp = KTb -yk+beta*(uk+vk);
        if lower(OPTK) == 'h'
            fk = real(ifft2(fft2(Temp)./MDf));
        else
            fk = Temp./MDf;
        end


        
        yk = yk - beta*(uk+vk-fk);
        
        fk = fk- alpha*(fk-fold);
        yk = yk-alpha*(yk-yold);

        
        Relerr_u(i) = norm(uk(:)-uold(:))/norm(uold(:));
        Relerr_v(i) = norm(vk(:)-vold(:))/norm(vold(:));
        Relerr_f(i) = norm(fk(:)-vold(:))/norm(fold(:));


        fold = fk;  yold = yk; uold = uk; vold =vk;
        SNRu_v2(j)  = 20*log10(norm(I(:))/norm(fk(:)-I(:)));

        % SNRf(j)    = 20*log10(norm(I(:))/norm(fk(:)-I(:)));


        if isfield(opts, 'vr')

             vv = LS_Est(vr(:),vk(:));
             uu = LS_Est(ur(:),uk(:)); %ff = LS_Est(ur(:),uk(:));


            out.Ru(i) = norm(uk(:)-ur(:))/norm(ur(:));
            out.Rv(i) = norm(vk(:)-vr(:))/norm(vr(:));
            out.Rf(i) = norm(fk(:)-I(:))/norm(I(:));

            SNRu2(j) = 20*log10(norm(ur(:))/norm(uu(:)-ur(:)));
            SNRv2(j) = 20*log10(norm(vr(:))/norm(vv(:)-vr(:)));
            fprintf('       Inner:%d   SNR-u22 = %2.2f, SNR-v22 = %2.2f,  SNR-u+v22 = %2.2f  \n' , j, SNRu2(j),SNRv2(j),SNRu_v2(j));
        else

                        fprintf('        Inner:%d  SNR-f = %2.2f \n',j,  SNRu_v2(j));
        end


        if lower(OPTK) == 'h'
            K_uv = imfilter(uk+vk,K,'circular');
        else
            K_uv = K.*(uk+vk);
        end


  

        if Relerr_u(i)<1e-3 || Relerr_v(i) <1e-4 || Relerr_f(j)<1e-4
            break;
        end

    end


    if k > 1
        Lgx0=Lgx;
    end
    Lgx = norm(D*uk(:));

    if k>5
        tt(k) = Lgx/Lgx0;
        if Lgx < tau*Lgx0
            break;
        else
            tmp  = abs(Wk*(L)*uk(:));
            tmp = tmp/max(tmp);
            %w = 1-tmp.^2;
            w = cos(pi.*tmp/2);
            newW = spdiags(w,0,2*sz,2*sz);
            Wk   = newW.*Wk;
        end
    else
            tmp  = abs(Wk*(L)*uk(:));
            tmp = tmp/max(tmp);
            w = cos(pi.*tmp/2);
            %w = 1-tmp.^2;
            newW = spdiags(w,0,2*sz,2*sz);
            Wk   = newW.*Wk;
    end


%     figure(2)
%     subplot(2,2,1)
%     imshow(b)
%     subplot(2,2,2)
%     imshow(uk)
%     subplot(2,2,3)
%     imshow(vk,[])
%     subplot(2,2,4)
%     imshow(uk+vk)
%     title( ['Outer Iter = ', num2str(k)])
%     pause(0.1);
    %
    %     figure(3)
    %     weightstemp = diag(Wk);
    %     weightstemp = weightstemp(length(weightstemp)/2 +1:end);
    %     imagesc(reshape((weightstemp),n1,n1)), axis image, axis off
    %     c= colorbar;
    %     c.FontSize = 15;
    %     mytitle=sprintf('Horizontal weight');
    %     axis('image');
    %     axis('off');
    %     title(mytitle,'FontSize', 20)
    %   %  print(figure(2), '-dpng',strcat('Results\I\Horizontal_Weight', '.png'))
    %     pause(0.1);

end
%out.tt = tt;
%out.SNR = SNRu_v;
out.Weight = Weight;
out.tt = tt;
out.k  = k;


end


