
%���ڲ�ͬ��ͼƬ���Ե���tau�Լ�lambda

clear; clc; close all    
addpath test_images  function Images

% % %
fname = 'Boy'; n=256;      
cart = im2double(imread('boy.tif'));
text = im2double(imread('Texture4.tif'));
Opts.tau  = 1.005;   
Opts.lambda = 0.00002; 

%% 
% fname = 'Tom'; n=512;
% cart = im2double(imread('TomAndJerry.png'));
% text = im2double(imread('wool.png'));
% Opts.tau  = 1.005; 
% Opts.lambda = 0.00002;  
% % %
%%  
% fname = 'Testgray'; n=256;
% cart = im2double(imread('Test_gray.png'));
% text = im2double(imread('colortexture4.png')); %colortexture4
% text = rgb2gray(text);
% Opts.tau  = 1.0001; 
% Opts.lambda = 0.00003;  
% 

%% 
% fname = 'Circle'; n=256;
% cart = im2double(imread('Circle.png'));
% text = im2double(imread('Texture256.png'));
% Opts.tau  = 1.001; Opts.lambda = 0.00003;  


%mask    = floor(double(imread('mask1.bmp'))/255);
ureal   = 0.7*cart(1:n,1:n);
vreal   = 0.3*text(1:n,1:n);    r = 10;
[U,S,V] = svd(vreal);  S(r+1:end,r+1:end) = 0;
vlow = U*S*V';   
I = ureal +vlow;

ur = ureal; vr = vlow; 
Opts.ur = ur(1:n,1:n);
Opts.vr = vr(1:n,1:n);
Opts.I = I(1:n,1:n);


Opts.outeriter = 40;
Opts.inneriter = 10;



 %%%%%%%%%%% The  case of K=I  %%%%%%%%%%%%%%
OPTK = 'I';  K = 1; sigma = 0;
b =  Opts.I +sigma*randn(size(Opts.I)); 
Opts.beta = 0.001;  Opts.mu = 0.0001; %Opts.lambda = 0.00002; 


%  %%%%%%%%%%% The case of K=S  %%%%%%%%%%%%%%
%  OPTK = 'S';
%  K    = mask(:,:,1); 
%  b   = K.*I;
%  %Opts.tau  = 1.05;
%  Opts.beta = 0.001;  Opts.mu = 0.002;  Opts.lambda = 0.0002; 

% %%  %%%%%%%%% The case of K= H  %%%%%%%%%%%%%%
% OPTK = 'H';   Opts.tau  = 1.01;  % for Boy  %Opts.tau  = 1.006; for Tom 
% K    = fspecial('disk',3);
% b    =  Opts.I;
% b    = imfilter(b,K,'circular');
% Opts.beta = 0.001;  Opts.mu = 0.0001;  Opts.lambda = 0.00001;  
%%

[u,v,f,out] = LR_Weight_new(b, K, Opts, OPTK); 

uu  = LS_Est(ur(:),u(:));
vv  = LS_Est(vr(:),v(:));
ff =  LS_Est(I(:), u(:)+v(:));
SNRf  = 20*log10(norm(I(:))/norm(f(:)-I(:)));
SNRuv = 20*log10(norm(I(:))/norm(ff(:)-I(:)));
SNRu  = 20*log10(norm(ur(:))/norm(uu(:)-ur(:)));
SNRv  = 20*log10(norm(vr(:))/norm(vv(:)-vr(:)));
fprintf('Iter %d SNR-u = %2.2f, SNR-v = %2.2f  SNRu+v = %3.2f SNRf = %3.2f  \n',out.k,SNRu,SNRv, SNRuv, SNRf);



figure(4)
subplot(1,3,1)
imshow(u)
subplot(1,3,2)
imshow(v,[])
subplot(1,3,3)
imshow(f)


% imwrite(u, strcat('New_Results/', OPTK,'/',num2str(Opts.lambda),'_',fname,'_cartoon','.png' ))
% imwrite(map01(v), strcat('New_Results/', OPTK,'/',num2str(Opts.lambda),'_',fname,'_texture','.png' ))
% imwrite(f, strcat('New_Results/', OPTK,'/',num2str(Opts.lambda),'_',fname,'_u+v','.png' ))

return;

% չʾȨ�ؾ���

Weight = out.Weight;
j = 1;


figure(9), clf
weightstemp = Weight(:,j);
% figure()
% plot(weightstemp)

%plot(weightstemp)
weightstemp = weightstemp(1: length(weightstemp)/2);
subplot(2,3,1)
imagesc(reshape(log10(weightstemp),n,n)), axis image, axis off
c= colorbar;
c.FontSize = 10;
mytitle=sprintf('Vertical Iter %d',j);
axis('image');
axis('off');
title(mytitle)

subplot(2,3,2)
j = floor(out.k /2)+1;
weightstemp = Weight(:,j);
weightstemp = weightstemp(1: length(weightstemp)/2);
imagesc(reshape(log10(weightstemp),n,n)), axis image, axis off
c= colorbar;
c.FontSize = 10;
mytitle=sprintf('Vertical Iter %d',j);
axis('image');
axis('off');
title(mytitle)

subplot(2,3,3)
j = out.k;
weightstemp = Weight(:,j);
weightstemp = weightstemp(1: length(weightstemp)/2);
imagesc(reshape(log10(weightstemp),n,n)), axis image, axis off
c= colorbar;
c.FontSize = 10;
mytitle=sprintf('Vertical Iter %d',j);
axis('image');
axis('off');
title(mytitle)


subplot(2,3,4)
j=1;
weightstemp = Weight(:,j);
weightstemp = weightstemp(length(weightstemp)/2 +1:end);
imagesc(reshape(log10(weightstemp),n,n)), axis image, axis off
c= colorbar;
c.FontSize = 10;
mytitle=sprintf('Horizontal Iter %d',j);
axis('image');
axis('off');
title(mytitle)

subplot(2,3,5)
j = floor(out.k/2)+1;
weightstemp = Weight(:,j);
weightstemp = weightstemp(length(weightstemp)/2 +1:end);
imagesc(reshape((weightstemp),n,n)), axis image, axis off
c= colorbar;
%c.FontSize = 16;
mytitle=sprintf('Horizontal Iter %d',j);
axis('image');
axis('off');
title(mytitle)

subplot(2,3,6)
j = out.k;
weightstemp = Weight(:,j);
weightstemp = weightstemp(length(weightstemp)/2 +1:end);
imagesc(reshape((weightstemp),n,n)), axis image, axis off
c= colorbar;
%c.FontSize = 16;
mytitle=sprintf('Horizontal Iter %d',j);
axis('image');
axis('off');
title(mytitle)
save(strcat('New_Results/', OPTK,'/',fname,'Weight','.mat' ), 'Weight')



