
%% 计算最小二乘近似
%% v 为真实的； v_hat为估计的
function vv = LS_Est(v,v_hat)

% 计算均值
v_bar = mean(v);
v_hat_bar = mean(v_hat);

% 求解最优解
a = (v'*v_hat - length(v)*v_bar*v_hat_bar) / (v_hat'*v_hat - length(v)*v_hat_bar^2);
b = v_bar - a*v_hat_bar;

vv = a*v_hat+b; 

end