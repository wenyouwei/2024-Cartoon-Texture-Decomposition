function y = map01(f)  
f = f - min(f(:));  
y = f/max(f(:)); 
end