function [Y]=SVT(X,alpha)

[U,S,V] = svd(X,'econ');
D = diag(S);
%% �˷���
% x = max(abs(s)-alpha,0).*sign(s);
% S(1:length(s), 1:length(s)) = diag(x); 
ind  = find(D>alpha);
D    = diag(D(ind) - alpha);

Y = U(:,ind) * D * V(:,ind)';
%% ��Ȩ�˷���


%     w_sigma  =  alpha .* (1 ./ ( s + 1e-5 )); % Ȩ��
%     ind  = find(s>w_sigma);  % minind =(D>thr);  D = minind.*D;
%     D    = diag(s(ind)-w_sigma(ind));
%     Y   = U(:,ind) * D * V(:,ind)';
    

end