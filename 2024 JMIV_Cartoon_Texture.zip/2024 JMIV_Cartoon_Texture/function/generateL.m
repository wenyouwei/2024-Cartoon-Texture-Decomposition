function  [L, D ,Dx, Dy] = generateL(n)   %% ����ϡ��ľ���L, Dx,�Լ� Dy  L = [Dx;Dy]
I  = speye(n);  
c  = [-1,1];
nd = n-1; nd=n;
L  = sparse(nd,n);
% L  = L + sparse(1:nd,(1:nd),c(1)*ones(1,nd),nd,n);
% L  = L + sparse(1:nd,(1:nd)+1,c(2)*ones(1,nd),nd,n);

L = L + sparse(1:nd, 1:nd, -ones(1, n), nd, n);
L = L + sparse(1:nd-1, 2:n, ones(1, n-1), nd, n);
L(end, :) = 0;


Dx = kron(I,L); Dy=kron(L,I);
L = [Dx;Dy];
L = sparse(L);
D = L;
L = 10*L;

end